// Ref: http://www.expert-oracle.com/list-tns-entries-from-tnsnames-ora-using-java/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// import com.sun.org.apache.xerces.internal.xs.StringList;

public class ReadTns {
	
//	public static void main(String args[]) 
	public static String[] getTNS() 
	{
		BufferedReader br = null;
		String pattern = "^([^#()\\W ][a-zA-Z0-9.]*(?:[.][a-zA-Z]*\\s?=)?)"; //Regular Expression Pattern for TNS Alias
		Pattern r = Pattern.compile(pattern);
		String tnsList[] = new String [10];

/*		String ipPatternExp = "[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+"; //Regular Expression Pattern for TNS Alias
		Pattern ipPattern = Pattern.compile(ipPatternExp);

		String portPatternExp = "[0-9]{4}"; //Regular Expression Pattern for TNS Alias
		Pattern portPattern = Pattern.compile(portPatternExp);
*/
		try 
		{
 
			String sCurrentLine; 
			int i = 0;
			br = new BufferedReader(new FileReader("C:\\oracle\\product\\10.2.0\\client_1\\NETWORK\\ADMIN\\TNSNAMES.ORA")); 
			while ((sCurrentLine = br.readLine()) != null) 
			{
				System.out.println(sCurrentLine);
				// 10.10.3.159:1521:tlsdb
				
				Matcher tnsMatcher = r.matcher(sCurrentLine);
				if(tnsMatcher.find())
				{					
					System.out.println("TNS FOUND");
					System.out.println(tnsMatcher.group().toUpperCase());				
					tnsList[i] = tnsMatcher.group().toUpperCase();
					i++;
				}

/*				
				Matcher ipMatcher = ipPattern.matcher(sCurrentLine);
				if(ipMatcher.find())
				{					
					//System.out.println(ipMatcher.group().toUpperCase());
					ipAddress = ipMatcher.group().toUpperCase();
				}

				Matcher portMatcher = portPattern.matcher(sCurrentLine);
				if(portMatcher.find())
				{					
					//System.out.println(portMatcher.group().toUpperCase());				
					portNumber = portMatcher.group().toUpperCase();
				}


				System.out.println(ipAddress + ":" + portNumber + ":" + tnsService);
				if (ipAddress != null && portNumber != null && tnsService !=null  ) {
					// 10.10.3.159:1521:tlsdb

					sConnectString = ipAddress + ":" + portNumber + ":" + tnsService;
					System.out.println(sConnectString);
				}
*/

			}
 
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			try 
			{
				if (br != null)br.close();
			} 
			catch (IOException ex) 
			{
				ex.printStackTrace();
			}
		}
		return tnsList;
	}	
}