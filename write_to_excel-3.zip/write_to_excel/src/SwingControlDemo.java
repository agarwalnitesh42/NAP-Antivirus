
import java.io.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import writer.WriteExcel;
import jxl.write.*;

// import java.io.File;
import java.io.IOException;

public class SwingControlDemo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JPanel controlPanel;

	private String loginTypeStr;
	private String tnsServiceStr;
	private String tnsConnList[];
	private static String tnsConnStr;

	private String batchIdStr;
	private String prefixStr;
	private String countStr;
	private String scriptPath;
	// private String dbStr;
	private String dbURL;
	private String dbDriver;
	private String dbUser;	
	private String dbPasswd;
	
	final JTextField batchIdText = new JTextField(10);
	final JTextField prefixText = new JTextField(10);
	final JTextField totalCountText = new JTextField(3);
	final JTextField scriptPathText = new JTextField(10);
	final JFileChooser c = new JFileChooser();
	final JOptionPane msgPane =  new JOptionPane();

	private JButton selectScriptFile = new JButton("Select Script to Run");
	private JButton createLogin = new JButton("Create Logins");
	private JButton lockExamLogin = new JButton("Lock Exam Logins");

	private JLabel batchIdLabel = new JLabel("Batch Id : ", JLabel.LEFT);
	private JLabel prefixLabel = new JLabel("Prefix : ", JLabel.LEFT);
	private JLabel totalCountLabel = new JLabel("Total number of Participants : ", JLabel.LEFT);
	private JLabel scriptPathLabel = new JLabel("Path of the Script file : ", JLabel.LEFT);
	private JLabel loginTypeLabel = new JLabel("Type of login : ", JLabel.LEFT);
	final DefaultComboBoxModel<String> loginType = new DefaultComboBoxModel<String>();
	final JComboBox<String> loginTypeCombo = new JComboBox<String>(loginType);
	JScrollPane loginTypeListScrollPane = new JScrollPane(loginTypeCombo);

	private JLabel tnsServiceLabel = new JLabel("Database : ", JLabel.LEFT);
	final DefaultComboBoxModel<String> tnsService = new DefaultComboBoxModel<String>();
	final JComboBox<String> tnsServiceCombo = new JComboBox<String>(tnsService);
	JScrollPane tnsServiceListScrollPane = new JScrollPane(tnsServiceCombo);

	Connection con;
	CallableStatement stmt;

	public SwingControlDemo() {
		prepareGUI();
	}

	public static void main(String[] args) {
		SwingControlDemo swingControlDemo = new SwingControlDemo();
		swingControlDemo.showTextFieldDemo();
	}

	private void prepareGUI() {
		JFrame.setDefaultLookAndFeelDecorated(true);

		this.setSize(400, 400);
		this.setLayout(new GridLayout(2, 3));
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});

		selectScriptFile.addActionListener(new OpenL());
		createLogin.addActionListener(new CreateL());
		lockExamLogin.addActionListener(new LockL());

		controlPanel = new JPanel();
		controlPanel.setBackground(Color.cyan);
		controlPanel.setLayout(new FlowLayout());

		this.add(controlPanel);
		this.setVisible(true);
	}

	private void showTextFieldDemo() {
		controlPanel.add(batchIdLabel);    controlPanel.add(batchIdText);
		controlPanel.add(prefixLabel); 	   controlPanel.add(prefixText);
		controlPanel.add(totalCountLabel); controlPanel.add(totalCountText);
		controlPanel.add(scriptPathLabel); controlPanel.add(scriptPathText);

		controlPanel.add(selectScriptFile);
		controlPanel.add(loginTypeLabel);
		loginType.addElement ("Exam");
		loginType.addElement ("Practice");
		loginTypeCombo.setSelectedIndex(0);
		controlPanel.add(loginTypeListScrollPane);

		controlPanel.add(tnsServiceLabel);
	
		String tnsList[] = new String [10];
		tnsList = ReadTnsString.getTNS();

		tnsConnList = ReadTnsString.getTnsConnStr();

		for(String tnsName:tnsList){
			if (tnsName == null){
				break;				
			}
			tnsService.addElement (tnsName);
		}  
		
		loginTypeCombo.setSelectedIndex(0);
		controlPanel.add(tnsServiceListScrollPane);

		
		controlPanel.add(createLogin);				
		controlPanel.add(lockExamLogin);

		this.setVisible(true);
	}

	class OpenL implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// "Open" dialog:
			int rVal = c.showOpenDialog(SwingControlDemo.this);
			if (rVal == JFileChooser.APPROVE_OPTION) {
				System.out.println("File selected: " + c.getSelectedFile().getAbsolutePath());
				scriptPathText.setText(c.getSelectedFile().getAbsolutePath());
			}

			if (rVal == JFileChooser.CANCEL_OPTION) {
				scriptPathText.setText("You pressed cancel. Script file not selected.");
			}
		}
	}

	class CreateL implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// String strCommand;	
			boolean isExceptionRaised = false;
			setValue();
		    
			try {
	    
			    // load the database driver
			    Class.forName(dbDriver); 	
			    System.out.println("Driver loaded");
			    
			    con = DriverManager.getConnection(dbURL, dbUser, dbPasswd); 	
			    System.out.println("Connected to DB");
			
				// Commented now
				// con = DriverManager.getConnection("jdbc:oracle:thin:@10.10.3.159:1521:tlsdb", "sys as sysdba", "cluster123");
				// System.out.println("Connected to DB");
			    
			    // calling procedure to create users
				String sqlProcedure = "{call login.create_users (?, ?, ?, ?)}";
				stmt=con.prepareCall(sqlProcedure);
				stmt.setString(1, batchIdStr);
				stmt.setString(2, prefixStr);        
				stmt.setInt(3, Integer.parseInt(countStr));
				stmt.setString(4, loginTypeStr);

				stmt.execute();
				System.out.println("Users Created...");
				
			} catch 
			(SQLException e1) {
				isExceptionRaised = true;
				if(e1.getErrorCode() == 00001){					
					JOptionPane.showMessageDialog(SwingControlDemo.this,
							"Prefix is already used. Please change the prefix.",
							"Prefix Error",
							JOptionPane.ERROR_MESSAGE);

					System.out.println("Prefix is already used. Please change the prefix");

				} else {
					e1.printStackTrace();
				}
			} catch 
			(ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}finally{
				try {
					stmt.close();
					con.close();
				} catch 
				(SQLException e1) {
					e1.printStackTrace();
				}
			}

			if (isExceptionRaised == true){
				isExceptionRaised = false;
			}
			else{
				if (loginTypeStr.equalsIgnoreCase("exam")){
					String excelfileName = "d:/ExamLogins/"+ prefixStr.toUpperCase() + "_logins.xls";
					runSchemaExamLogin(excelfileName, prefixStr.toUpperCase(), scriptPath );
					JOptionPane.showMessageDialog(SwingControlDemo.this, "Login details stored at " + excelfileName + "\n" + countStr + " Logins created.", "Exam Login File", JOptionPane.PLAIN_MESSAGE);
					System.out.println(excelfileName);					
				}
				else{
					runSchemaPracticeLogin(prefixStr.toUpperCase(), scriptPath);
					JOptionPane.showMessageDialog(SwingControlDemo.this, countStr + " Logins created.", "Practice Login", JOptionPane.PLAIN_MESSAGE);
				}

			}
		}
	}

	class LockL implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			System.out.println("Lock Logins clicked");
			prefixStr 	= prefixText.getText().toString();
			try {
				// step1 load the driver class 
				Class.forName(dbDriver);
				System.out.println("driver class loaded");
				// step2 create the connection object 
				con = DriverManager.getConnection(dbURL, dbUser, dbPasswd);

				String sqlQuery = "SELECT username FROM DBA_users WHERE username like '" + prefixStr.toUpperCase() + "%'";

				Statement stmt1=con.createStatement();
				ResultSet rs = stmt1.executeQuery(sqlQuery);

				while (rs.next()) {
					String sqlProcedure = "{call login.lock_login (?)}";
					stmt=con.prepareCall(sqlProcedure);
					stmt.setString(1, rs.getString(1));				
					stmt.execute();
				}
				con.close();

			} catch (Exception e1) {
				System.out.println("Exception Raised.");
				System.out.println(e1);
			}
		}
	}

	private void runSchemaPracticeLogin(String loginPrefix, String scriptPath) {
		try {

			// step1 load the driver class 
			Class.forName(dbDriver);

			// step2 create the connection object 
			con = DriverManager.getConnection(dbURL, dbUser, dbPasswd);

			// step3 create the statement object
			Statement stmt = con.createStatement();

			// step4 execute query
			String sqlQuery = "SELECT username FROM DBA_users WHERE username like '"+loginPrefix.toUpperCase() +"' || '%' AND default_tablespace='PRACTICE'";
			ResultSet rs = stmt.executeQuery(sqlQuery);

			while (rs.next()) {
//				String strCommand = "echo exit | sqlplus " + rs.getString(1) + "@"+ tnsServiceStr + "/practice @\"" + scriptPath + "\"";
				String strCommand = "echo exit | sqlplus " + rs.getString(1) + "/practice@" + "\"" + tnsConnStr + "\"" + " @\"" + scriptPath + "\"";
				//				sqlplus user/password@(description=(address_list=(address=.......ODS))) 

				System.out.println(strCommand);

				ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", strCommand);
				builder.redirectErrorStream(true);
				Process p;
				try {
					p = builder.start();
					//p.getErrorStream().available() > 0;

					BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
					String line;
					while (true) {
						line = r.readLine();
						if (line == null) { break; }
						System.out.println(line);
						
					}
				} catch 
				(IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void runSchemaExamLogin(String excelfileName, String loginPrefix, String scriptPath){
		WriteExcel test = new WriteExcel();
		test.setOutputFile(excelfileName);
		try {
			test.write(scriptPath, loginPrefix.toUpperCase(), tnsServiceStr, dbDriver, dbURL, dbUser, dbPasswd, tnsConnStr);
		} catch (WriteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	private void setValue(){
		tnsConnStr		= tnsConnList[tnsServiceCombo.getSelectedIndex()];
		tnsServiceStr	= tnsServiceCombo.getSelectedItem().toString();
		loginTypeStr	= loginTypeCombo.getSelectedItem().toString();
		batchIdStr		= batchIdText.getText().toString();
		prefixStr 		= prefixText.getText().toString();
		countStr 		= totalCountText.getText().toString();
		scriptPath 		= c.getSelectedFile().getAbsolutePath();

		// tell the driver where to look for the TNSNAMES.ORA file
		System.setProperty( 
				  "oracle.net.tns_admin",
				  "C:\\oracle\\product\\10.2.0\\client_1\\NETWORK\\ADMIN");

		// tnsServiceStr is net service name from the TNSNAMES.ORA file
		dbDriver = "oracle.jdbc.OracleDriver";
	    dbURL = "jdbc:oracle:thin:@" + tnsServiceStr;
	    dbUser = "sys as sysdba";
	    dbPasswd = "password";		
	    // dbStr = "\"sys@tnsServiceStr/password as sysdba\"";
	}


}

