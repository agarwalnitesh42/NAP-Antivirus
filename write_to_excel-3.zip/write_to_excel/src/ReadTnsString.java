import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ReadTnsString {

	public static String tnsConnStr[] = new String [10];
	
	

	public static String[] getTnsConnStr() {
		return tnsConnStr;
	}
	//	public static void main(String args[]) 
	public static String[] getTNS() 
	{
		BufferedReader br = null;
		String pattern = "^([^#()\\W ][a-zA-Z0-9.]*(?:[.][a-zA-Z]*\\s?=)?)"; //Regular Expression Pattern for TNS Alias
		Pattern r = Pattern.compile(pattern);
		String tnsList[] = new String [10];

		try 
		{
			String sCurrentLine; 
			int i = 0;
			int j = 0;
			br = new BufferedReader(new FileReader("C:\\oracle\\product\\10.2.0\\client_1\\NETWORK\\ADMIN\\TNSNAMES.ORA")); 
			boolean flag = false;
			String nextTNS = "";
			String connStr="";

			Matcher tnsMatcher;
			sCurrentLine = br.readLine();
			do
			{
				// Added for missing Services
				if (flag)
				{
					flag = false;
					tnsMatcher = r.matcher(nextTNS);
					connStr = sCurrentLine;
				}
				else
				{
					tnsMatcher = r.matcher(sCurrentLine);
				}
				if(tnsMatcher.find())
				{					
					System.out.println("TNS :" + tnsMatcher.group().toUpperCase());				
					tnsList[i] = tnsMatcher.group().toUpperCase();
					i++;
					
					while ((sCurrentLine = br.readLine()) != null){
						tnsMatcher = r.matcher(sCurrentLine);
						if(tnsMatcher.find()){
							flag = true;
							nextTNS = tnsMatcher.group().toUpperCase();
							break;
						}
						else{
							connStr =  connStr + sCurrentLine;			
						}
					}
					System.out.println("Connection Str: " + connStr);
					tnsConnStr[j] = connStr;
					j++;
				}
			}while ((sCurrentLine = br.readLine()) != null);
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			try 
			{
				if (br != null)br.close();
			} 
			catch (IOException ex) 
			{
				ex.printStackTrace();
			}
		}
		return tnsList;
	}	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//String[] a = ReadTnsString.getTNS();

	}

}
