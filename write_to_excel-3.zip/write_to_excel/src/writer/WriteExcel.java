package writer;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;

import jxl.CellView;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class WriteExcel {

	private WritableCellFormat timesBoldUnderline;
	private WritableCellFormat times;
	private String inputFile;

	Connection con;
	
	public void setOutputFile(String inputFile) {
		this.inputFile = inputFile;
	}

	public void write(String scriptPath, String loginPrefix, String dbName, String dbDriver, String dbURL, String dbUser, String dbPasswd, String tnsConnStr) throws IOException, WriteException {
		
		File dir = new File("D:\\ExamLogins");
        if (!dir.exists()) {
            if (dir.mkdir()) {
                System.out.println("Directory is created!");
            } else {
                System.out.println("Failed to create directory!");
            }
        }
		
		File file = new File(inputFile);
		WorkbookSettings wbSettings = new WorkbookSettings();

		wbSettings.setLocale(new Locale("en", "EN"));

		WritableWorkbook workbook = Workbook.createWorkbook(file, wbSettings);
		workbook.createSheet("loginPrefix", 0);
		WritableSheet excelSheet = workbook.getSheet(0);
		createLabel(excelSheet);
		createContent(excelSheet, scriptPath, loginPrefix, dbName, dbDriver, dbURL, dbUser, dbPasswd, tnsConnStr);

		workbook.write();
		workbook.close();
	}

	private void createLabel(WritableSheet sheet) throws WriteException {
		// Lets create a times font
		WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
		// Define the cell format
		times = new WritableCellFormat(times10pt);
		// Lets automatically wrap the cells
		times.setWrap(true);

		// create create a bold font with underlines
		
		
		WritableFont times10ptBoldUnderline = new WritableFont(
				WritableFont.COURIER, 10, WritableFont.BOLD, false,
				UnderlineStyle.SINGLE);
		timesBoldUnderline = new WritableCellFormat(times10ptBoldUnderline);
		// Lets automatically wrap the cells
		timesBoldUnderline.setWrap(true);

		CellView cv = new CellView();
		cv.setFormat(times);
		cv.setFormat(timesBoldUnderline);
		cv.setAutosize(true);

		// Write a few headers
		addCaption(sheet, 0, 0, "UserName");
		addCaption(sheet, 1, 0, "Password");
		addCaption(sheet, 2, 0, "HostString");

	}

	private void createContent(WritableSheet sheet, String scriptPath, String loginPrefix, String dbName, String dbDriver, String dbURL, String dbUser, String dbPasswd, String tnsConnStr) throws WriteException,
			RowsExceededException {
		// Write a few number

		ResultSet rs = getData(loginPrefix, dbDriver, dbURL, dbUser, dbPasswd);

		try {
			int i = 1;
			while (rs.next()) {
				addLabel(sheet, 0, i, rs.getString(1));
				addLabel(sheet, 1, i, rs.getString(2));
				addLabel(sheet, 2, i, dbName);

				//String strCommand = "echo exit | sqlplus " + rs.getString(1) + "@" + dbName + "/"+ rs.getString(2) + " @\"" + scriptPath + "\"";
				String strCommand = "echo exit | sqlplus " + rs.getString(1) + "/" + rs.getString(2)+ "@" + "\"" + tnsConnStr + "\"" + " @\"" + scriptPath + "\"";

				System.out.println(strCommand);

				ProcessBuilder builder = new ProcessBuilder("cmd.exe", "/c", strCommand);
				
				String FILE_PATH="d:\\ExamLogins\\DB.log";

				try {
					FileWriter write = new FileWriter (FILE_PATH, true);
					PrintWriter print_line  = new PrintWriter(write);

					builder.redirectErrorStream(true);
					Process p;
					try {
						p = builder.start();
						BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
					    String line;
					    while (true) {
					        line = r.readLine();
					        if (line == null) { break; }
					        System.out.println(line);
					        print_line.printf("%s" + "%n", line);
					    }
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					print_line.close();
				} catch (IOException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				i++;
			}
			
			con.close();
		} catch (SQLException e) {
			System.out.println("Error writing to excel file");
		}
	}

	private void addCaption(WritableSheet sheet, int column, int row, String s)
			throws RowsExceededException, WriteException {
		Label label;
		label = new Label(column, row, s, timesBoldUnderline);
		sheet.addCell(label);
	}

	private void addLabel(WritableSheet sheet, int column, int row, String s)
			throws WriteException, RowsExceededException {
		Label label;
		label = new Label(column, row, s, times);
		sheet.addCell(label);
	}

	public static void main(String[] args) throws WriteException, IOException {
//		WriteExcel test = new WriteExcel();
//		test.setOutputFile("d:/temp/lars.xls");
//		test.write();
		
		
		System.out
				.println("Please check the result file under c:/temp/lars.xls");
	}

	private ResultSet getData(String loginPrefix, String dbDriver, String dbURL, String dbUser, String dbPasswd) {
		try {
			// step1 load the driver class
			Class.forName(dbDriver);

			// step2 create the connection object
			con = DriverManager.getConnection(dbURL, dbUser, dbPasswd);
			
			// step3 create the statement object
			Statement stmt = con.createStatement();

			// step4 execute query
			String sqlQuery = "select * from exam_user_info where prefix='" + loginPrefix + "'";
			ResultSet rs = stmt.executeQuery(sqlQuery);		
			return rs;

		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}

}
